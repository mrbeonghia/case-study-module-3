create
    definer = root@localhost procedure customerName()
SELECT customerName FROM customers;

