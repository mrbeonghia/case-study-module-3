create view customers_view as
select `classicmodels`.`customers`.`customerName`   AS `customerName`,
       `classicmodels`.`customers`.`customerNumber` AS `customerNumber`
from `classicmodels`.`customers`;

