create
    definer = root@localhost procedure save_student(IN id_new int, IN firstName_new varchar(255),
                                                    IN lastName_new varchar(255), IN email_new varchar(255),
                                                    IN phoneNumber_new varchar(255), IN classRoomId_new int)
save_students : 
BEGIN
if 
		not exists(select * from classroom where id = classRoomId_new) then
		leave save_students ;
	else
			if(exists(select * from student where id = id_new))
				then update student
					 set firstName = firstName_new, lastName = lastName_new, email =  email_new, phoneNumber = phoneNumber_new, classroomId = classRoomId_new
					 where id = id_new;
			else 
				insert into student
				value(id_new, firstName_new, lastName_new,email_new, phoneNumber_new,classRoomId_new);
			end if;
	end if;
END;

